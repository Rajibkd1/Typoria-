<?php
include "./db_connection.php";
require "./mailer.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Check if fields are empty
    if (empty($name) || empty($email) || empty($password)) {
        echo "All fields are required.";
        exit();
    }

    // Check if the email is already registered
    $checkEmailSql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($checkEmailSql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "This email is already registered.";
        exit();
    }

    // Generate a random OTP
    $otp = rand(100000, 999999);

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert the user data and OTP into the `otp_verification` table
    $insertSql = "INSERT INTO otp_verification (name, email, password, otp) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    $stmt->bind_param("sssi", $name, $email, $hashedPassword, $otp);

    if ($stmt->execute()) {
        // Send OTP via email
        $subject = "Email Verification - Your OTP Code";
        $message = "Hello $name,\n\nYour OTP for email verification is: $otp\n\nThank you for registering.";
        if (sendEmail($email, $subject, $message)) {
            header("Location: verify_otp.php?email=$email");
            exit();
        } else {
            echo "Failed to send OTP. Please try again.";
        }
    } else {
        // Add this line to display the error
        echo "Registration failed: " . $stmt->error;
    }    
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
    <div class="min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full bg-white p-8 rounded-lg shadow-lg">
            <div class="text-center mb-6">
                <h2 class="text-3xl font-extrabold text-gray-900">
                    Create an account
                </h2>
                <p class="text-gray-600 mt-2">Get started with your free account</p>
            </div>

            <form class="space-y-4" action="Registration.php" method="POST">
                <input type="hidden" name="remember" value="true">
                <div>
                    <label for="name" class="sr-only">Name</label>
                    <input id="name" name="name" type="text" required class="appearance-none rounded-full relative block w-full px-3 py-2 bg-gray-100 border border-transparent placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 placeholder-opacity-50 text-sm" placeholder="Name">
                </div>
                <div>
                    <label for="email" class="sr-only">Email address</label>
                    <input id="email" name="email" type="email" required class="appearance-none rounded-full relative block w-full px-3 py-2 bg-gray-100 border border-transparent placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 placeholder-opacity-50 text-sm" placeholder="Email address">
                </div>
                <div>
                    <label for="password" class="sr-only">Password</label>
                    <input id="password" name="password" type="password" required class="appearance-none rounded-full relative block w-full px-3 py-2 bg-gray-100 border border-transparent placeholder-gray-500 text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 placeholder-opacity-50 text-sm" placeholder="Password">
                </div>
                <div>
                    <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-full text-white bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 hover:from-purple-700 hover:via-pink-700 hover:to-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Register
                    </button>
                </div>
                <p class="text-center text-gray-600 text-xs">By clicking Register, you agree to our <a href="#" class="underline">Terms</a> and confirm that you have read our <a href="#" class="underline">Data Policy</a>.</p>
            </form>
        </div>
    </div>
</body>

</html>
