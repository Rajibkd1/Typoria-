<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Your App</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 min-h-screen ">

    <?php include "./navbar.php"; ?>

    <div class="container max-w-md mx-auto mt-5">
        <div class="bg-white shadow-xl rounded-lg overflow-hidden">
            <div class="p-6">
                <h2 class="text-2xl font-bold text-gray-800 text-center mb-6">Welcome Back</h2>
                <p class="text-gray-600 text-center mb-4">Sign in to your account</p>

                <form method="POST" action="loginSubmit.php" class="space-y-6">
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                        <div class="mt-1">
                            <input type="email" name="email" id="email" class="w-full rounded-lg border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-3" placeholder="Enter your email" required>
                        </div>
                        <p class="text-xs text-gray-500 mt-2">We’ll never share your email with anyone else.</p>
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                        <div class="mt-1">
                            <input type="password" name="password" id="password" class="w-full rounded-lg border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 p-3" placeholder="Enter your password" required>
                        </div>
                    </div>

                    <div class="flex items-center justify-between">
                        <label for="remember-me" class="flex items-center">
                            <input type="checkbox" id="remember-me" name="remember-me" class="form-checkbox h-4 w-4 text-indigo-600 border-gray-300 rounded">
                            <span class="ml-2 text-sm text-gray-600">Remember me</span>
                        </label>
                        <a href="#" class="text-sm text-indigo-600 hover:underline">Forgot your password?</a>
                    </div>

                    <button type="submit" class="w-full py-3 px-4 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Sign In
                    </button>
                </form>
            </div>
            <div class="bg-gray-50 p-4 text-center">
                <p class="text-gray-600 text-sm">
                    Don't have an account? 
                    <a href="./Registration.php" class="text-indigo-600 font-medium hover:underline">Sign up</a>
                </p>
            </div>
        </div>

        <p class="text-center text-gray-400 text-xs mt-6">
            &copy;2025 Your Company. All rights reserved.
        </p>
    </div>
</body>

</html>
